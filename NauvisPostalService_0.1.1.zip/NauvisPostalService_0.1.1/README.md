Based largely on TransportDrones (https://mods.factorio.com/mod/Transport_Drones) (https://github.com/Klonan/Transport_Drones)

Most of the util code is from there too (unless it is rubbish, in which case I wrote it)

Write something here Michael
